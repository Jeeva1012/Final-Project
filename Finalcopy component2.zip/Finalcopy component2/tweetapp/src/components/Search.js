import React, { Component } from "react";
import ApiService from "../service/ApiService";

class search extends Component{

    constructor(props){
        super(props);
        this.state ={
            username:'',
            result :[],
            message:'',
            show: true
          }
            this.search = this.search.bind(this)
     
     
    }
    
    componentDidMount() {
        this.search();
        
    }

    search(){
               
        ApiService.search(window.localStorage.getItem("user"))
        .then((res) => {
          let user = res.data;
         console.log(user)
         this.setState({result: res.data})
         
      }) .catch(error =>{
        console.log(error)
        this.setState({message:'username not available'})
      })
      setTimeout(() => this.setState({message:''}), 3000);
      }
      changeHandler = (e) =>
        this.setState({ [e.target.name]: e.target.value });
    render(){
        const {message} = this.state
      return(
          <div>
          <h2 className="text-center">User Details</h2>
                  
                  <table className="table table-striped">
                      <thead>
                          <tr>
                              <th>Username</th>
                              <th>Tweet</th>
                              <th>tweeted on</th>
                              
                          </tr>
                      </thead>
                      <tbody>
                          {
                              this.state.result.map(
                          user =>
                                      <tr >
                                          <td>{user.username}</td>
                                          <td>{user.tweet}</td>
                                          <td>{user.timeAgo}</td>
                                        
                                      </tr>
                                      
                              )
                              
                          }
                        
                      </tbody>
                     
                  </table>
                     {
                              message ? <div>{message}</div> : null
                     }
                  </div>
      
             
      );     
          
        
      
      
    }
  }
  export default search;
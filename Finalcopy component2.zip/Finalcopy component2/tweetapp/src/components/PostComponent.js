import React, { Component } from "react";
import ApiService from "../service/ApiService.jsx";
import HeaderComponent from "./HeaderComponent.js";
class PostComponent extends Component {
    constructor(props){
        super(props);
        this.state ={
            tweet:'',
            message: null
        }
        this.postTweet = this.postTweet.bind(this);
    }

    postTweet = (e) => {
        e.preventDefault();
        console.log(this.state)
        let user = {tweet: this.state.tweet};
    
        ApiService.addPost(user,window.localStorage.getItem("username"))
       
       
            .then(res => {
                console.log(res)
                this.setState({message : 'Posted successfully.' })
                this.props.history.push('/allTweet');
            })
    }

     changeHandler = (e) =>
        this.setState({ [e.target.name]: e.target.value });


    
    render() {
        const { tweet } = this.state
        return (
            <div>
                <HeaderComponent/>
            <form className="auth-wrapper-register">
                <h3>Post your thoughts...</h3>

                <div className="form-group">
                    <label>Tweet</label>
                    <input type="text" className="form-control" placeholder="Post a tweet" name="tweet" value={tweet}  onChange={this.changeHandler} />
                </div>
                <div>
                    <button className="btn btn-primary btn-block" onClick={this.postTweet}>Post</button>
                </div>
            </form>
            </div>
        );
    }
}

export default PostComponent;
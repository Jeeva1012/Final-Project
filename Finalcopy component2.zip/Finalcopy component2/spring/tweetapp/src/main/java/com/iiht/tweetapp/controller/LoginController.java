package com.iiht.tweetapp.controller;





import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.iiht.tweetapp.model.RegisterUser;
import com.iiht.tweetapp.repository.UserRepository;
import com.iiht.tweetapp.service.LoginService;


@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/v1.0/tweets")
public class LoginController {
	@Autowired
	LoginService loginservice;
	

	RegisterUser registerUser;
	
	@Autowired
	UserRepository userRepo;
	
	/*
	 * @PostMapping("/login") public RegisterUser login(RegisterUser user) throws
	 * Exception{ return loginservice.login(user); }
	 */
	
	
	@GetMapping(path = "/login")
	public String login() {
		return "LOGGED IN";
	}
	
	/*
	 * @PostMapping(path="/login") public @ResponseBody Object
	 * user(@RequestParam("username") String username,
	 * 
	 * @RequestParam("password") String password, HttpSession session, ModelMap
	 * modelMap) {
	 * 
	 * registerUser= userRepo.findByEmail(username);
	 * System.out.println("list of users"+registerUser); String user=
	 * registerUser.getEmail();
	 * 
	 * 
	 * registerUser= userRepo.findByPassword(password); String pass=
	 * registerUser.getPassword(); if(username.equalsIgnoreCase(user) &&
	 * password.equalsIgnoreCase(pass)) { session.setAttribute("userName",
	 * username); return session.getAttribute("userName");
	 * 
	 * } else { modelMap.put("error", "Invalid Account"); return "index"; }
	 * 
	 * }
	 */
	  @GetMapping("/logout")
		public String logout(HttpSession session) {
			session.removeAttribute("username");
			return "redirect:../account";
		}

}

package com.iiht.tweetapp.repository;



import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

//import com.iiht.tweetapp.model.LoginUser;
import com.iiht.tweetapp.model.RegisterUser;

@Repository
public interface UserRepository extends MongoRepository<RegisterUser, String> {
	 RegisterUser findByEmail(String email);

	//@Query("select * from User where password = ?")
	RegisterUser findByPassword(String password);

	RegisterUser findByLoginId(String username);



	
}

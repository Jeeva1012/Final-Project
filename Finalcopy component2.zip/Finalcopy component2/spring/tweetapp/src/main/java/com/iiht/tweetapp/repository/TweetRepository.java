package com.iiht.tweetapp.repository;



import org.springframework.data.mongodb.repository.MongoRepository;

import com.iiht.tweetapp.model.TweetUser;

public interface TweetRepository extends MongoRepository<TweetUser, Integer>{

	

	TweetUser findByUsername(String username);
	
	

}

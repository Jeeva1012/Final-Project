package com.iiht.tweetapp.service;


import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iiht.tweetapp.model.ReplyUser;
import com.iiht.tweetapp.repository.ReplyRepository;

@Service
public class ReplyService {

	@Autowired
	ReplyRepository replyRepo;
	
	
	public ReplyUser postReplyTweet(String username, ReplyUser replytweet, String tweetId) {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		System.out.println(dtf.format(now));
		String time = dtf.format(now);

		replytweet.setUsername(username);
		replytweet.setTweetId(tweetId);
		replytweet.setLike(0);
		replytweet.setTime(time);
		
		return replyRepo.save(replytweet);
	}

	public List<ReplyUser> getReplyTweet(String tweetId){
		
List<ReplyUser> tweet = replyRepo.findByTweetId(tweetId);
		
		for(int i=1;i<tweet.size();i++) {
	    try {
	    
	        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	        //DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss"); 
	        Date past = format.parse(tweet.get(i).getTime());
	        Date now = new Date();
	        long diff = now.getTime() - past.getTime(); 
	        long milliSecPerMinute = 60 * 1000; //Milliseconds Per Minute
	        long milliSecPerHour = milliSecPerMinute * 60; //Milliseconds Per Hour
	        long milliSecPerDay = milliSecPerHour * 24; //Milliseconds Per Day
	        long milliSecPerMonth = milliSecPerDay * 30; //Milliseconds Per Month
	        long milliSecPerYear = milliSecPerDay * 365; //Milliseconds Per Year
	        
	        if (diff < milliSecPerMinute) {
	            tweet.get(i).setTimeAgo(TimeUnit.MILLISECONDS.toMillis(now.getTime() - past.getTime()) + " milliseconds ago");
	          }
	        
	        else if (diff < milliSecPerHour) {
	        	tweet.get(i).setTimeAgo(TimeUnit.MILLISECONDS.toMinutes(now.getTime() - past.getTime()) + " minutes ago");
	        }
	        else if (diff < milliSecPerDay) {
	        	tweet.get(i).setTimeAgo(TimeUnit.MILLISECONDS.toHours(now.getTime() - past.getTime()) + " hours ago");
	        }
	        else if (diff < milliSecPerMonth) {
	        	tweet.get(i).setTimeAgo(TimeUnit.MILLISECONDS.toDays(now.getTime() - past.getTime()) + " days ago");
	        }
	        else if(diff < milliSecPerYear) {
	        	//tweet.get(i).setTimeAgo(TimeUnit.MILLISECONDS.to(now.getTime() - past.getTime()) + " days ago");
	        	if (Math.round(diff / milliSecPerMonth) == 1) {
	        	      tweet.get(i).setTimeAgo(String.valueOf(Math.round(diff / milliSecPerMonth)) + "  month ago... ");
	        	    } else {
	        	    	tweet.get(i).setTimeAgo(String.valueOf(Math.round(diff / milliSecPerMonth)) + "  months ago... ");
	        	    }
	        }
	        else {
	            if (Math.round(diff / milliSecPerYear) == 1) {
	            	tweet.get(i).setTimeAgo(String.valueOf(Math.round(diff / milliSecPerYear)) + " year ago...");
	            } else {
	            	tweet.get(i).setTimeAgo(String.valueOf(Math.round(diff / milliSecPerYear)) + " years ago...");
	            }
	          }
	        replyRepo.save(tweet.get(i));
	        
	    }
	    catch (Exception j){
	        j.printStackTrace();
	    }
	    
	    
	 
		
		}	
	
		return replyRepo.findByTweetId(tweetId);
		
		
	}
}

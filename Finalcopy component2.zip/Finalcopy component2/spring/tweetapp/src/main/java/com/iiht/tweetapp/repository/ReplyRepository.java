package com.iiht.tweetapp.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.iiht.tweetapp.model.ReplyUser;

public interface ReplyRepository extends MongoRepository<ReplyUser, String>{

	List<ReplyUser> findByTweetId(String tweetId);
	

}

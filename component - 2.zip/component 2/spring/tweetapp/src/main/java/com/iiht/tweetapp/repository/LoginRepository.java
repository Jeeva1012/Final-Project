package com.iiht.tweetapp.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.iiht.tweetapp.model.RegisterUser;


public interface LoginRepository extends MongoRepository<RegisterUser, String> {

	RegisterUser findByEmail(String email);

}

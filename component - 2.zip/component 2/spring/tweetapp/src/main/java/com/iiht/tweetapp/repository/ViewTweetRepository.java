package com.iiht.tweetapp.repository;



import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.iiht.tweetapp.model.TweetUser;

@Repository
public interface ViewTweetRepository extends MongoRepository<TweetUser, String> {

	List<TweetUser> findAllByUsername(String username);
	

	void deleteByusernameAndId(String username,String id);

	TweetUser findByUsernameAndId(String username, String id);

	@Query("{'username':{'$regex':'?0','$options':'i'}}")  
    List<TweetUser> searchByUsername(String username);


	
}

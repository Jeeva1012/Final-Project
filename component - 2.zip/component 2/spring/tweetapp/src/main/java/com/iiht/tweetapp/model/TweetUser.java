package com.iiht.tweetapp.model;



import javax.validation.constraints.Size;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "Tweet")
public class TweetUser {
	
	@Id
	private String id;
	private String username;
	
	@javax.validation.constraints.NotBlank
	    @Size(max = 140)
	private String tweet;
	private String time;
	private int like;
	private String timeAgo;
	public TweetUser() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public TweetUser(String id, String username, String tweet, String time, int like, String timeAgo) {
		super();
		this.id = id;
		this.username = username;
		this.tweet = tweet;
		this.time = time;
		this.like = like;
		this.timeAgo = timeAgo;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getTweet() {
		return tweet;
	}
	public void setTweet(String tweet) {
		this.tweet = tweet;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public int getLike() {
		return like;
	}
	public void setLike(int like) {
		this.like = like;
	}
	public String getTimeAgo() {
		return timeAgo;
	}
	public void setTimeAgo(String timeAgo) {
		this.timeAgo = timeAgo;
	}
	
	
	
}

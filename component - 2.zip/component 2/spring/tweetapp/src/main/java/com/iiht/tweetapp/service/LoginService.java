package com.iiht.tweetapp.service;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iiht.tweetapp.model.RegisterUser;
import com.iiht.tweetapp.repository.LoginRepository;


@Service
public class LoginService {

	@Autowired
   private LoginRepository loginRepository;

	public RegisterUser logUser(String username) {
		return loginRepository.findByEmail(username);
		
	}
	
}

package com.iiht.tweetapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.iiht.tweetapp.service.PasswordResetService;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/v1.0/tweets")
public class PasswordController {

	@Autowired
	PasswordResetService passwordResetService;
	
	@GetMapping("/{username}/forgot")
	public String reset(@PathVariable String username, @RequestParam String newpassword){
		System.out.println("exit");
		return passwordResetService.resetPassword(username,newpassword);
	}
	
}
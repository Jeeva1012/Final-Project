
package com.iiht.tweetapp.service;

import java.util.List;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iiht.tweetapp.model.RegisterUser;
import com.iiht.tweetapp.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;

	public String register(RegisterUser user) throws Exception {
		
		final Logger logger = LoggerFactory.getLogger(this.getClass());
		RegisterUser registeruser=userRepository.findByEmail(user.getEmail());
		boolean existingUser=registeruser==null?true:false;
		logger.info("Checking UserAlready Exist"+existingUser);
		if(!existingUser) {
			throw new Exception("EmailId already Exist"); 
			
			}
		
		else {
			System.out.println(user);
		userRepository.save(user);
		
		}
		return "Register User successfully";
	}

	public List<RegisterUser> getUser() {
		List<RegisterUser> allUser = userRepository.findAll();
		return allUser;
	}
}

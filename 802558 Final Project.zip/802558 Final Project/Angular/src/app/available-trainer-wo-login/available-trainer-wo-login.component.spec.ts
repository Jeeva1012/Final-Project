import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AvailableTrainerWoLoginComponent } from './available-trainer-wo-login.component';

describe('AvailableTrainerWoLoginComponent', () => {
  let component: AvailableTrainerWoLoginComponent;
  let fixture: ComponentFixture<AvailableTrainerWoLoginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AvailableTrainerWoLoginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AvailableTrainerWoLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';
import { CompletedTrainingService } from '../completed-training.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-main-page',
  templateUrl: './admin-main-page.component.html',
  styleUrls: ['./admin-main-page.component.css']
})
export class AdminMainPageComponent implements OnInit {
  private users: string[];
  private mentor: string[];
  constructor(private httpservice : CompletedTrainingService,private router: Router) { }

  ngOnInit() {
    this.reloadData();
  }
  reloadData() {
    this.httpservice.getblockusers().subscribe(value=>this.users=value as string[]);
    this.httpservice.getblockmentors().subscribe(value=>this.mentor=value as string[]);
  }
}

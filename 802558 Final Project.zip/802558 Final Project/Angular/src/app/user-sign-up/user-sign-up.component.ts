import { Component, OnInit } from '@angular/core';
import { CompletedTrainingService } from '../completed-training.service';
import { Router } from '@angular/router';

export class User{
  username:string;
  password:string;
  mail:string;
  roleid:Role;
}
export class Role{
  roleid:number;
  rolename:string;
}

@Component({
  selector: 'app-user-sign-up',
  templateUrl: './user-sign-up.component.html',
  styleUrls: ['./user-sign-up.component.css']
})

export class UserSignUpComponent implements OnInit {
  uname:string;
  upass:string;
  val:string;
  
  username:string;
  mail:string;
  password:string;
  invaliduser:string;
  
  user:User=new User();
  role:Role=new Role();
  constructor(private router: Router,private service:CompletedTrainingService) { }

  ngOnInit() {
  }

  
  onsign(){
    if(this.username!=null && this.mail!=null && this.password!=null){
    this.user.username=this.username;
    this.user.mail=this.mail;
    this.user.password=this.password;
    this.role.roleid=1;
    this.role.rolename="user";
    this.user.roleid=this.role;
    this.service.saveUser(this.user).subscribe();

    this.username=null;
    this.mail=null;
    this.password=null;
    this.val="";
    this.router.navigate(['/userlogin']);
    }
    else{
      this.val = "Enter valid details";
    }
    
  }

}

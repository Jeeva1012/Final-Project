import { Component, OnInit } from '@angular/core';




import { CompletedTrainingService } from '../completed-training.service';
 
@Component({
  selector: 'app-user-completed-training',
  templateUrl: './user-completed-training.component.html',
  styleUrls: ['./user-completed-training.component.css']
})
export class UserCompletedTrainingComponent implements OnInit {

private tech = [];

constructor(private http:CompletedTrainingService){}

  //constructor(private httpservice : HttpClient) { }

  // course : string[];


  ngOnInit() {
    // this.httpservice.get('../../assets/coursedetails.json').subscribe(

    //   data=>{
    //     this.course = data as string[];
    //   },
    //   (err : HttpErrorResponse) => {
    //     console.log(err.message);
    //   }
    // )
    // this.reload();
    this.completed();
  }

  // reload(){
  //   this.bb.getusers().subscribe(value=>this.tech=value as string[]);
  // }
    completed() {
      this.http.completedTraining().subscribe(value=>this.tech = value as string[]);
    }

  

  myFunction() {
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById("myInput");
    filter = input.value.toUpperCase();
    table = document.getElementById("myTable");
    tr = table.getElementsByTagName("tr");
    for (i = 0; i < tr.length; i++) {
      td = tr[i].getElementsByTagName("td")[2];
      if (td) {
        txtValue = td.textContent || td.innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
          tr[i].style.display = "";
        } else {
          tr[i].style.display = "none";
        }
      }       
    }
  }
}



import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule} from '@angular/common/http';
import {FormsModule} from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { MentorloginComponent } from './mentorlogin/mentorlogin.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { UsermainpageComponent } from './usermainpage/usermainpage.component';
import { UserCurrentTrainingComponent } from './user-current-training/user-current-training.component';
import { UserCompletedTrainingComponent } from './user-completed-training/user-completed-training.component';
import { MentorMainPageComponent } from './mentor-main-page/mentor-main-page.component';
import { MentorCompletedTrainingComponent } from './mentor-completed-training/mentor-completed-training.component';
import { MentorEditSkillsComponent } from './mentor-edit-skills/mentor-edit-skills.component';
import { MentorPaymentComponent } from './mentor-payment/mentor-payment.component';
import { AdminMainPageComponent } from './admin-main-page/admin-main-page.component';
import { AdminEditSkillsComponent } from './admin-edit-skills/admin-edit-skills.component';
import { UserSignUpComponent } from './user-sign-up/user-sign-up.component';
import { MentorSignUpComponent } from './mentor-sign-up/mentor-sign-up.component';
import { AvailableTrainerWoLoginComponent } from './available-trainer-wo-login/available-trainer-wo-login.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    UserloginComponent,
    MentorloginComponent,
    AdminloginComponent,
    UsermainpageComponent,
    UserCurrentTrainingComponent,
    UserCompletedTrainingComponent,
    MentorMainPageComponent,
    MentorCompletedTrainingComponent,
    MentorEditSkillsComponent,
    MentorPaymentComponent,
    AdminMainPageComponent,
    AdminEditSkillsComponent,
    UserSignUpComponent,
    MentorSignUpComponent,
    AvailableTrainerWoLoginComponent,
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule, 
    HttpClientModule,
    FormsModule
   
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

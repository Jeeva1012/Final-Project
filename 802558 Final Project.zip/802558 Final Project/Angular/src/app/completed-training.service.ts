import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CompletedTrainingService {

  private baseUrl = "http://localhost:8080/api/phase4";

  

  constructor(private http:HttpClient) { }
// url1
completedTraining():Observable<any>{
    return this.http.get(`${this.baseUrl}-user/user/completed`);
  }

// url2
  addtech(adder:string):Observable<any>{
    
    return this.http.get(`${this.baseUrl}-admin/admin/addentry/${adder}`);
  }
  // url3
  removetechnology(minus:string):Observable<any>{
    return this.http.get(`${this.baseUrl}-admin/admin/remove/${minus}`);
  }
  // url4
  displaytechnology():Observable<any>{
    return this.http.get(`${this.baseUrl}-admin/admin/allskills`);
  }
  // url5
  getblockusers():Observable<any>{ 
    return this.http.get(`${this.baseUrl}-user/user/training`);
  } 
// url6
  getblockmentors():Observable<any>{ 
    return this.http.get(`${this.baseUrl}-mentor/mentor/profile`);
  } 
//  url6
  currentTraining():Observable<any>{
    return this.http.get(`${this.baseUrl}-user/user/current`);
  }
// url7
  getmentor():Observable<any>{ 
    return this.http.get(`${this.baseUrl}-mentor/mentor/profile`);
  }
  // url8
  saveUser(user:object){
    return this.http.post(`${this.baseUrl}-security/main/addentry`,user);
  }
  // url9
  getmentorcurrent():Observable<any>{ 
    return this.http.get(`${this.baseUrl}-mentor/mentor/current`);
  }
// url`0
  getmentorcompleted():Observable<any>{ 
    return this.http.get(`${this.baseUrl}-mentor/mentor/completed`);
  }
  // url11
  savesignup(user:object){
    return this.http.post(`${this.baseUrl}-security/main/addentry`,user);
  }
//url12
  savementor(mentor:object){
    return this.http.post(`${this.baseUrl}-mentor/mentor/addentry`,mentor);
  }
  // url13
  getloginmentor(mentor:string):Observable<any>{
    return this.http.get(`${this.baseUrl}-security/main/${mentor}`);
  }
}

import { Component, OnInit } from '@angular/core';
import { UserCompletedTrainingComponent } from '../user-completed-training/user-completed-training.component';
import { CompletedTrainingService } from '../completed-training.service'
@Component({
  selector: 'app-admin-edit-skills',
  templateUrl: './admin-edit-skills.component.html',
  styleUrls: ['./admin-edit-skills.component.css']
})
export class AdminEditSkillsComponent implements OnInit {

  adder:string;
  minus:string;

  private technologies: string[];
  constructor(private httpservice:CompletedTrainingService) { }

  ngOnInit() {
    this.showtech();
  }

  addmethod(){
    if(this.adder != ""){
    this.httpservice.addtech(this.adder).subscribe(data=>console.log(data),error=>console.log(error));
    this.adder = "";
  }
  }
  removemethod(){
    if(this.minus!=""){
      this.httpservice.removetechnology(this.minus).subscribe(data=>console.log(data),error=>console.log(error));
      this.minus = "";
      }
  }
  showtech(){
    this.httpservice.displaytechnology().subscribe(value=>this.technologies=value as string[]);
  }
}


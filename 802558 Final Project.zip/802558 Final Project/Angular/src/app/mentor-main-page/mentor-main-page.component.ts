import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {HttpErrorResponse} from '@angular/common/http';
import { CompletedTrainingService } from '../completed-training.service';

@Component({
  selector: 'app-mentor-main-page',
  templateUrl: './mentor-main-page.component.html',
  styleUrls: ['./mentor-main-page.component.css']
})
export class MentorMainPageComponent implements OnInit {

  constructor(private http : CompletedTrainingService) { }

  mentorcourse : string[];
  private current : string [];

  ngOnInit() {
    // this.httpservice.get('../../assets/mentorcourse.json').subscribe(

    //   data=>{
    //     this.mentorcourse = data as string[];
    //   },
    //   (err : HttpErrorResponse) => {
    //     console.log(err.message);
    //   }
    // )
    this.reloaddata();
  }
  reloaddata(){
    
    this.http.getmentorcurrent().subscribe(value=>this.current=value as string[]);
  }

  }

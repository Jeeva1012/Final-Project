import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MentorMainPageComponent } from './mentor-main-page.component';

describe('MentorMainPageComponent', () => {
  let component: MentorMainPageComponent;
  let fixture: ComponentFixture<MentorMainPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MentorMainPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MentorMainPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

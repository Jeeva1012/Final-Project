import { Component, OnInit } from '@angular/core';
import { Time } from '@angular/common';
import { Router } from '@angular/router';
import { CompletedTrainingService } from '../completed-training.service';

export class Authorization{
  username:string;
  password:string;
  mail:string;
  roleid:Role;
}
export class Role{
  roleid:number;
  rolename:string;
}

export class Mentor{
username:String;
password:String;
valueFrom:Time;
valueTo:Time;
mobile:String;
training:Training;
skill:Skills;
}
export class Training{
coursename:String;
percentage:Int16Array;
amountpaid:Int16Array;
amountremaining:Int16Array;
status:boolean;
}
export class Skills{
skillname:String;
}
@Component({
  selector: 'app-mentor-sign-up',
  templateUrl: './mentor-sign-up.component.html',
  styleUrls: ['./mentor-sign-up.component.css']
})
export class MentorSignUpComponent implements OnInit {
  mname:string;
  mpassword:string;
  printform:boolean = false;

newname:string; 
newpass:string;
mail:string;
newfrom:Time;
newto:Time;
newskill:String;
newphone:string;

arr:String[];

  caption: string;
  invalidmentor: string;
  // mentorarr:String[][];
  // itr:number = -1;
  
  auth:Authorization = new Authorization();
  private auth2:Authorization = new Authorization();
  role:Role = new Role();
  ment:Mentor=new Mentor();
  train:Training=new Training();
  skill:Skills=new Skills();

  constructor(private router: Router,private http:CompletedTrainingService) { }

  ngOnInit() {
  }
  mentorsignup(){
    if(this.newname!=null && this.newpass!=null && this.newfrom!=null &&
       this.newto!=null && this.newphone!=null ){
      
        this.ment.username = this.newname;
        this.ment.password = this.newpass;
        this.ment.valueFrom = this.newfrom;
        this.ment.valueTo = this.newto;
        this.ment.mobile = this.newphone;
        // this.train.
        // this.ment.training=;
        // this.arr = this.newskill.split(","); 
        // this.ment.skill = this.arr;
        this.auth.username=this.newname;
        this.auth.mail=this.mail;
        this.auth.password=this.newpass;
        this.role.roleid=2;
        this.role.rolename="mentor";
        this.auth.roleid=this.role;
        this.http.savesignup(this.auth).subscribe();
        this.http.savementor(this.ment).subscribe();
        this.router.navigate(['/userlogin']);
    }
    else {
      this.caption =  "Enter details!!!";
    }
  }

}

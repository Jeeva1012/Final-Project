import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {HttpErrorResponse} from '@angular/common/http';

@Component({
  selector: 'app-mentor-edit-skills',
  templateUrl: './mentor-edit-skills.component.html',
  styleUrls: ['./mentor-edit-skills.component.css']
})
export class MentorEditSkillsComponent implements OnInit {

  constructor(private httpservice : HttpClient) { }

  mentorcourse : string[];


  ngOnInit() {
    this.httpservice.get('../../assets/mentorcourse.json').subscribe(

      data=>{
        this.mentorcourse = data as string[];
      },
      (err : HttpErrorResponse) => {
        console.log(err.message);
      }
    )
  }
  }

import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {HttpErrorResponse} from '@angular/common/http';


@Component({
  selector: 'app-mentor-payment',
  templateUrl: './mentor-payment.component.html',
  styleUrls: ['./mentor-payment.component.css']
})
export class MentorPaymentComponent implements OnInit {

  constructor(private httpservice : HttpClient) { }

  mentorcourse : string[];


  ngOnInit() {
    this.httpservice.get('../../assets/mentorcourse.json').subscribe(

      data=>{
        this.mentorcourse = data as string[];
      },
      (err : HttpErrorResponse) => {
        console.log(err.message);
      }
    )
  }
  }

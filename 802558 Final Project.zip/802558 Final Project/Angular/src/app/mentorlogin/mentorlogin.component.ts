import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { Time } from '@angular/common';
import { CompletedTrainingService } from '../completed-training.service';
export class Authorization{
  username:string;
  password:string;
  mail:string;
  roleid:Role;
}
export class Role{
  roleid:number;
  rolename:string;
}

export class Mentor{
username:String;
password:String;
valueFrom:Time;
valueTo:Time;
mobile:String;
training:Training;
skill:Skills;
}
export class Training{
coursename:String;
percentage:Int16Array;
amountpaid:Int16Array;
amountremaining:Int16Array;
status:boolean;
}
export class Skills{
skillname:String;
}
@Component({
  selector: 'app-mentorlogin',
  templateUrl: './mentorlogin.component.html',
  styleUrls: ['./mentorlogin.component.css']
})
export class MentorloginComponent implements OnInit {
  mname:string;
  mpassword:string;
  printform:boolean = false;

newname:string; 
newpass:string;
mail:string;
newfrom:Time;
newto:Time;
newskill:String;
newphone:string;

arr:String[];

  caption: string;
  invalidmentor: string;
  // mentorarr:String[][];
  // itr:number = -1;
  
  // auth:Authorization = new Authorization();
  private auth2:Authorization = new Authorization();
  role:Role = new Role();
  ment:Mentor=new Mentor();
  train:Training=new Training();
  skill:Skills=new Skills();

  constructor(private router: Router,private http:CompletedTrainingService) { }

  ngOnInit(){}
  
    
    mentorlogin(){
      if((this.mname != null)&&(this.mpassword != null)){
        this.http.getloginmentor(this.mname).subscribe(value=>this.auth2=value as Authorization);
        console.log(this.auth2.password);
        // console.log(this.auth2.roleid.roleid);
        if((this.mpassword == this.auth2.password)&&(this.auth2.roleid.roleid == 2)){
          this.invalidmentor =  "";
          this.router.navigate(['/mentormainpage']);
        }
        else{
          this.invalidmentor = "Not a registered mentor!!!";
        }
      }
      else{
        this.invalidmentor = "Enter valid details!!!";
      }
    }


}

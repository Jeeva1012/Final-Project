import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { MentorloginComponent } from './mentorlogin/mentorlogin.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { UserSignUpComponent } from './user-sign-up/user-sign-up.component';
import { MentorSignUpComponent } from './mentor-sign-up/mentor-sign-up.component';
import { UsermainpageComponent } from './usermainpage/usermainpage.component';
import { UserCompletedTrainingComponent } from './user-completed-training/user-completed-training.component';
import { UserCurrentTrainingComponent } from './user-current-training/user-current-training.component';
import { MentorMainPageComponent } from './mentor-main-page/mentor-main-page.component';
import { MentorCompletedTrainingComponent } from './mentor-completed-training/mentor-completed-training.component';
import { MentorEditSkillsComponent } from './mentor-edit-skills/mentor-edit-skills.component';
import { MentorPaymentComponent } from './mentor-payment/mentor-payment.component';
import { AdminMainPageComponent } from './admin-main-page/admin-main-page.component';
import { AdminEditSkillsComponent } from './admin-edit-skills/admin-edit-skills.component';
import { AvailableTrainerWoLoginComponent } from './available-trainer-wo-login/available-trainer-wo-login.component';


const routes: Routes = [
  {path:'',redirectTo:'/home', pathMatch:'full'},
  {path:'home',component:HomeComponent},
  {path:'userlogin',component:UserloginComponent},
  {path:'mentorlogin',component:MentorloginComponent},
  {path:'adminlogin',component:AdminloginComponent},
  {path:'usersignup',component:UserSignUpComponent},
  {path:'mentorsignup',component:MentorSignUpComponent},
  {path:'usermainpage',component:UsermainpageComponent},
  {path:'usercompletedtraining',component:UserCompletedTrainingComponent},
  {path:'usercurrenttraining',component:UserCurrentTrainingComponent},
  {path:'mentormainpage',component:MentorMainPageComponent},
  {path:'mentorcompletedtraining',component:MentorCompletedTrainingComponent},
  {path:'mentoreditskills',component:MentorEditSkillsComponent},
  {path:'mentorpayment',component:MentorPaymentComponent},
  {path:'adminmainpage',component:AdminMainPageComponent},
  {path:'admineditskills',component:AdminEditSkillsComponent},
  {path:'availabletrainerwithoutlogin',component:AvailableTrainerWoLoginComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

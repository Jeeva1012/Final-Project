import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {HttpErrorResponse} from '@angular/common/http';
import { CompletedTrainingService } from '../completed-training.service';

@Component({
  selector: 'app-mentor-completed-training',
  templateUrl: './mentor-completed-training.component.html',
  styleUrls: ['./mentor-completed-training.component.css']
})
export class MentorCompletedTrainingComponent implements OnInit {

  constructor(private http : CompletedTrainingService) { }

  mentorcourse : string[];
  private completed : string [];

  ngOnInit() {
    // this.httpservice.get('../../assets/mentorcourse.json').subscribe(

    //   data=>{
    //     this.mentorcourse = data as string[];
    //   },
    //   (err : HttpErrorResponse) => {
    //     console.log(err.message);
    //   }
    // )
    this.reloaddata();
  }
  reloaddata(){
    this.http.getmentorcompleted().subscribe(value=>this.completed=value as string[]);
    
  }
  }

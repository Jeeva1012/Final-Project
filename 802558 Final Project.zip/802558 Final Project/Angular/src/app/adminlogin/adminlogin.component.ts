import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent implements OnInit {

  username:string;
  password:string;
  constructor(private userlogin: Router) { }

  ngOnInit(){}
  submit() {
    
    if(this.username!=null && this.password!=null){
      this.userlogin.navigate(['/adminmainpage']);
      // alert("Enter valid mail address");
  }
  else{
    alert("Enter valid details");
  }
}

}
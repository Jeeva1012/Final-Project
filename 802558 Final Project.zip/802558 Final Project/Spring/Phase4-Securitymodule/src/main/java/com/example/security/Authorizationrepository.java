package com.example.security;

import javax.validation.Valid;

import org.springframework.data.repository.CrudRepository;



public interface Authorizationrepository extends CrudRepository<Authorization, Integer> {

	Authorization findByUsername(@Valid String username);

}

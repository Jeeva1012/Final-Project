package com.example.admin;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Skill {
	@Id
    @GeneratedValue(strategy=GenerationType.AUTO)
 	private Integer skillid;
 	
    private String skillname;
    
    public Skill() {
		super();
		}

	public Skill(Integer skillid, String skillname) {
		super();
		this.skillid = skillid;
		this.skillname = skillname;
	}

	public Integer getSkillid() {
		return skillid;
	}

	public void setSkillid(Integer skillid) {
		this.skillid = skillid;
	}

	public String getSkillname() {
		return skillname;
	}

	public void setSkillname(String skillname) {
		this.skillname = skillname;
	}
    

}

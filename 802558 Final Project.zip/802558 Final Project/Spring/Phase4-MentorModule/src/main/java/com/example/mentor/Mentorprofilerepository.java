package com.example.mentor;

import org.springframework.data.repository.CrudRepository;



public interface Mentorprofilerepository extends CrudRepository<Mentorprofile, Integer>  {

}

package com.example.mentor;

import java.sql.Time;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;



@Entity
public class Mentorprofile {
	@Id
 	private String username;
	
    private String password;
    
    @Column(name="valueFrom")
    private Time from;
    
    @Column(name="valueTo")
    private Time to;
    
    private String mobile;
    
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="training")
    private Training training;
	
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="skill")
    private Skills skill;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Time getFrom() {
		return from;
	}

	public void setFrom(Time from) {
		this.from = from;
	}

	public Time getTo() {
		return to;
	}

	public void setTo(Time to) {
		this.to = to;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public Training getTraining() {
		return training;
	}

	public void setTraining(Training training) {
		this.training = training;
	}

	public Skills getSkill() {
		return skill;
	}

	public void setSkill(Skills skill) {
		this.skill = skill;
	}

	public Mentorprofile(String username, String password, Time from, Time to, String mobile, Training training,
			Skills skill) {
		super();
		this.username = username;
		this.password = password;
		this.from = from;
		this.to = to;
		this.mobile = mobile;
		this.training = training;
		this.skill = skill;
	}

	public Mentorprofile() {
		super();
		// TODO Auto-generated constructor stub
	}

	
    

}

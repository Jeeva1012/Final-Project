package com.example.user;

import org.springframework.data.repository.CrudRepository;



public interface Usertrainingrepository extends CrudRepository<Usertraining,Integer> {

}

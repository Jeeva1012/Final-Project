
import React, { Component } from 'react'
import ApiService from '../service/ApiService';
import { Link } from 'react-router-dom';
import HeaderComponent from './HeaderComponent';

class MyTweetComponent extends Component {

    constructor(props) {
        super(props)
        this.state = {
            username:'',
            tweets: [],
            message: '',
            
            
        }
        
        this.reloadTweetList = this.reloadTweetList.bind(this);
    }

    componentDidMount() {
        this.reloadTweetList();
        
    }
    reloadTweetList() {
        this.setState({username:window.localStorage.getItem("username")})
        ApiService.fetchMyTweet(window.localStorage.getItem("username"))
            .then((res) => {
                console.log(res)
                this.setState({tweets: res.data})
                
            })
            .catch(error =>{
                console.log(error)
                this.setState({message:'Error retreving data'})
            })
            setTimeout(() => this.setState({message:''}), 3000);
    }


    likeTweet(id,username){

        ApiService.fetchUserByIdAndUsername(id,username)
            .then((res) => {
                let user = res.data.result;
               console.log(user)
               window.localStorage.setItem("tweetCount",res.data)
               this.reloadTweetList();
            });
        
    }

    edittweet(id,username) {
        console.log(id);
        console.log(username);
        window.localStorage.setItem("tweetId", id);
        window.localStorage.setItem("tweetUsername", username);
        this.props.history.push('/updateTweet');
    }

    deletetweet(id,username) {
        console.log(id);
        console.log(username);
        ApiService.deleteTweet(id,window.localStorage.getItem("username"))
            .then(res => {
                this.setState({message : 'deleted successfully.'});
                this.reloadTweetList();
            });
    }
          
    render() {

        const { tweets,message } = this.state
        console.log(tweets)
        return (
            <div align="left">
             <HeaderComponent/>
                <h2 className="text-center">Tweet</h2>
                {
                    tweets.length ? tweets.map(tweet => 
                        <div class="card-body msg_card_body">
							<div class="d-flex justify-content-start mb-4">
								<div class="img_cont_msg">
							  
                                    <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxIQDxUPDxAQEBUQEA8VEBUQDxAPEBAQFRUWFhUXFRUYHSggGBomGxUVITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGhAQGy0lICYtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAOEA4QMBIgACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAABAUBAgMGBwj/xABDEAACAQEDCAcFBgQEBwAAAAAAAQIDBBEhBRITMUFRYXEGIjJSgZGhFEKxwdEHI3KSk+EVU4KiYsLw8SRDVGR0g7L/xAAbAQEAAgMBAQAAAAAAAAAAAAAABQYBAwQCB//EADMRAAICAAIHBwMEAgMAAAAAAAABAgMEEQUSEyExQVEyYXGBkbHRIqHBFCPh8AYzJELx/9oADAMBAAIRAxEAPwD7EAACbT1LkjY1p6lyRsARLR2vI5nS0dryOYB3su3wJBHsz1+HzK+3ZehDqw+8lwfVXjt8DVdfXTHWseSPddcrHlFZllaOz4lXaMpUoa5XvdHrMoLZlKrV7csO7HCP7kUhL9N8qY+b+P5JKrRvOx+nyXVXL79yC5yfyRFq5bry9/N5JIrwRlmkMTPjN+W72O6GEpjwivPedp22pLtVJv8AqZxc3vfmwDlc5S4tvzZuUIrgvYKT3vzOtO1VI9mpNcpM5AKclwb9WZcU+K9idSyxXj/zG/xJSJUOkEn24J8YtxfkU4OmvH4iHCb89/uaJ4WmXGKPTWfK1Ke3Ne6WHrqLOza71uPCney2ypSd9OTjw1x8iSo03JbrY596+Djt0av+j9fk96aVuyyksPSGMurWWY+8sY+O4uHNShemmmsGnemTdGJqvWdbz9/QjLKZ1vKayIwAN5rJ4AAIVXtPmam1XtPmagAAAEvRR3IzoluRuACHKo02k9rGklvZrPW+b+JgAk0oqSveL4nC22mlRjnTuW5LW3wRGt2VI0IXa5u+6PzfA8rabRKpLOm22/TluIvH6SjR9EN8vsvH4O3C4N2/VLcvfwJeUMqTq4LqR7qevm9pBAKxbbO2WtN5sm6641rViskAAaz2AAAAAAGDBkAAAAAwADJJsVvnRfVeG2Lxi/oRgeoWShLWg8meZQU1lJZo9hk630qywSUlri9fhvRYaNbkfP6c3FqUW008GsGj1ORssKp93Uwnseyf7llwGlFc9SzdLryf893oQ2KwTr+qG9exN0st7M6SW9mgJgjyTGCaTaTv1m+iW5Cl2VyNwDTRLcjB0ABF9ofD1HtD4epyABIVFPHHHEr8r2uNCOGM5dlYeb4Eu2WuNGlny2JXLa3sR4u02iVSbnN3tvwW5Ii9JY/YR1Idp/ZdTtweF2rzl2V9+41qVHJuUne3rbMAIqjbbzZPJZAAAAAAAAAAAAAAGMzOQABkwAAAAAADCZkAHpMiW9Vfu6jeetT7y+pc+zre/Q8FCTTvTuaxTWtM9jkfKKrQx7UcJL5rgWbReP2q2Vna5PqQmNwuzevHh7El1HHBXYGPaHw9TSr2nzNSZI86+0Ph6g5AA7ezvevIOhxRJKfpHbMynmRfWqYco7TVfdGmt2S4I911uyaiuZRZYt2mqXLswwjx3sggFJttlbNzlxZZa4KEVFcEAYMo1nsAAAAAAHOvWjTi5zlGEYpuUpNKMUtbbZ0PhXTnpPVtlonBScaNObjTgncnmu7Olvbav4HbgcFLFTaTyS4s5sTiFTHPm+B6npD9p6jJ07DBSud2lrJ3PjGC2cX5Hird0vt9bt2ur/62qS/sSKEwWenA4epZRivF739yEsxNtj3v8Fl/GrV/1Vp/Xq/UusmdPLdRfWrOtHbGrc/KWv4nkwbpUVSWTivQ8K2cXmpM+69GOmtK2LNfUml1oNrO5rvLkepjJNXrFPUfmmzV5U5xnTk4yi04tO5pn2roT0iVpoqTwaebVjsjPeuD1lf0jo1VLaV8OnQlsJjHP6J8fc9cACFJEAAAAAAHew2t0ainHZrW+O1HAHqMnCSlHijEoqSyfA9xSuqRU4tXSxRt7O968ik6MW3XRk+MPmvmekLrhMQr6lNefiVq+p1TcH/URvZ3v9GCSDoNRydaO/0Z4vKlp0taU9l90fwr/XqX+Va+ZRk9r6q5v9rzyxX9NX741Lxf4JbRtXGx+CAAIAlQEAAAAAAAAVnSS1ujYq9WDulChVcXulmu5+Z8c6FdEK2Vas4wkqcacXKpVmnJKb7Mbr7227+VzZ9d6Ywvydal/wBtVflFv5D7GLCqeSYVEsbRVrTk9rzZumv/AIfmWHRD1aZtcc/wRWNjrWxXLI+QdIOgtvsTbq2eU4J4VaP3tNrf1cY/1JHmLj9gFdbsgWSu769ks1V750acpebV5Kq/qjklhujPyhcdaNGU5KMIynJ6lFOUnySP07HoXk1O/wBgsvjRi15MtbFk+jQV1CjSordSpwpr0R6266HlYZ9T8yZS6K22zUI2m0WapSpzkoqU81POabV8b86OrW0j3/2YKPssGoq/TTU3djJ34N78Gl4H0vprkv2vJ1ooXXuVGbp3/wA2Cz4f3JLxPlv2Xv8A4Vf+Q/8AKcWPk5Yd+Jvw9epcvA+lgAqhNgAAAAAAAAG1Cq4TjOOuLTR7ihaYyipJ9pJ6ntPCnoOj9e+m4PXB+j/0ya0Nfq2Op8+Hiv49iN0lVnBTXL2L/TR3+jBEMlkzRDFH0jq4xhzk/gvmUxPy/VzrRL/DdHyX7kApukLNfEzffl6bix4SGrTFAAHGdAAAAAAAAABCyzR0lmrU+/Z60fODRc9FLB7PYLPQ1OnZ6Sl+Jxvl6tkM9DF4Jk9oxZUt9X7HBie35GTBkwSJpBkAAyfLejmTXZZVKclcvbbVm37YKq4xflFH1E8l0juz8MOtL5X+pz4pZ0yQr7aZLBpT7Kv3K/yNysEqAAAAAABcAACwyFVurXd9NeOtfArzpZKmbUhLdKL9TfhrNndGfRo1XQ165R7j2Obz9QTMN/qC760SsbzwlvnnVZvfUl8WcDNR4t8X8QUOb1pN979y1QWUUjAMmDyegAZAAAAAAABdWGpnU1wwfgUpNyXVuk4Pbq5kho69ws1G9z9znxEM463NFsYBgnjhQBkGTJzrVFCLm9UYtvkleeQpX15upPBJ4Ljr+hc9J7Xm01SWuo8fwrX63EGyUsyCjt28yJ0je19CZ0YeGbzZ2ABDHaAAAYMgwAZMGQAYMmDIBe/xTiZKG8Hd+vsOP9FAzPW+bMHS1xzak1unJepzOOayk13v3OqLzimAAeT0AAAAAAAAABGVzvWwFpkiwX/eTWHup7eLOjC4ed9ihD/xGq+2NUHKRIstdTjft2rczqRLfY5U3paWC95LZ+xyhlPvR8mWmUHF5EXCaks0WBrUmopyeCRCllNbIvxZizUZ2iV8sIJ7PgjEYtvJGZSSWbPP2qq6lrvlvVy3JRvRPLLL2Rc+KqUVm1KawS9+K2c9xS2S0Z63SXaRA6Sw067M3wZ24S6NkNxIABGnWAAAAAAAAAAAAAWn8O4A6v0dvQ5v1dZxy5TzbRPi014pEEuOk0b5xnddfFp81/uU5nHV6mImu/P1M4WetTF9wAByHQYMmDIAAIVvt8aSu7UnqX1NlNM7pqFazbPFlka4603kiZeRK+Uacfeznuh1v2KK02ydTtSw3LCPkRpO5eBZMP8A4+uN8vJfPwQ12lnwqXm/gzb+ktWV6p3U1jirpTfi9R7/AKE5Y9qsqz3fUo9Spvfdl4r1TPkt28vOh2V/ZbVFyd0Kt0Km5JvCXg/S8mK8LVTHVril/epHyvnZLObzPr5SZUydm31Kaw95LZxXAu0VPSLLMbLTwulUmupH/NLh8TGy2n0oxLERoi7JPJIiZOsDqu94RWt7+CPQQgopJK5LUlsPM9E8vaVKhVaU1fmO5JVFuu73xPTh0up6r4mK8XHFQVkOH3XcyDl3KSstnnXl7seou9N4RXmfI6OW6ym6jlnuTbd6Wt6y/wDtHyvpKyssH1aGM9zqtfJP1Z489uiFkMrEmu8bWUJZxeR7Wx5aUknNXXpO9cSxo2iE+zJP0Z4+y9hcjvGTWpkTiP8AH6pb6pZdz3r5R31aWmt1iz8NzPXgobHlSSwl1lx+TLulVUlfF3/IreJwtuHlq2Imab4XR1oM3ABzm4AAAHSzwzpxivecV5s5k7IdO+vF3X5t8n4avU3YeGvbGPVr3NdstSDl0R7HRrcDn7Rw9QXXZxKzmypy1Qz6L3w6y8Nfo2eaPcaB6ndjxPG22zunUlB+68OTxXoQOm6MpRtXPc/wS2jbdzrfj8nEwZBBEoYMmDIBxtddU4Ob2LDi9h5apNyblLFt3sucvz6sY75N+S/cpC4aBw8Y0bXnJ/ZFd0ra5W6nJe4ABPEYQ8ozV2bhe+GpEAn5RpXrOWzXyIBrZlH1voDlP2uzKMnfOhdCpvcfcl4pXc0yo6eWOMbSnGTvnCLknjdc7ld5ajzPQjLXsdsjKTup1bqdX8LeEvB48ry/6XWjSW2pujmpf0rH1bPeFh+9u6EbpuxLC7+Oay9/Yq8l2ZSr04yk0nUgm44SWK1PYz6P0ltysdnnXeNyugu9UfZXn6HzWnUzZKfdlGXk7yf9p+WtNXjZYO+FDGd2p1pL5Rd3izZjYZyj5nN/j9n0WLnmjxdWo5ScpNuUm3JvW23eyTk+ok813Y6ndiRSVk6le857NXM0ImyxABsMGSyyZas2WOp4S+TKw62d4+BGaVojbh23xW87MBa67kup6wHGzSvhF74o7FEay3FpQAAAL3o7RujKb953Lktfr8CihByaitbaS5vBHtLLY3CEYK7qpbdb2kvoajXudj4R93/BH6Rt1a1Dr7AHTQPh5gtBCEsoOk9izoqqljHCX4d/h8y80i3rzRrUUZJxbTTTTx2M0YmhXVOD5myqx1zUkeABJyjZHSqOOzXF74kYpM4Srk4S4ossJKSUlwYMgHk9FL0geMFwl8voVBa5ffXj+D5lUXzRMf8Ah1+H5Krj3/yJ/wB5A0jPrSjuuNyJQn99Jb/kSLTOTNEpq9XMp61PNk47tXIuSJlCles5a46+QabCaK8u8n2lzj1nfJa23e3xZSXnew18yad+DwfJnqmThM4dJYZX0NLit6+PQuLVWzIOXlxewoZSbbbd7bbbeLbZLyrXzpZqeEfiQz3iJOUslwRp0RhtjTrvjLf5chFXu5bS4o082Kju18yFk6le857MFzLA0pMlG0aVZ3LnKK9TciZQncor/Ff5Eu8ykxmgdKHa8zmb0X1jRi03RNdzNtD/AHY+J6awP7qPj8WdyLk1/dLnL4ks+dz7TLfHgYBk3oUXOShFXuTuMJNvJcQ2ks2W3Rmx503VawhhHjL9l8T1REsVGNKnGCaWascbsdpJz1vXmi6YLDfp6lDnxfiVzEXO2xy9PA2BppFvXmgdRoIYAANMp2FV6SXvJXwfHceOqQcW4yVzTaa3M+gw1Lkiny5krSLSU111rXfX1IfSmAdq2kO0uXVfJIYLFbN6kuD+x5YGGjJWCbOc6cXrinzSZjQQ7kfyxOoPSnJcG/U8uEXyOegh3Iflia+zU779HC/8ETsBtJdX6sakeiOWhh3IfliNBDuQ/LE6gztJdX6sakeiI/stP+VT/Tj9B7JT/lU/04/QkC4bSXV+rGpHoji7JT/l0/04/Q19jp/yqf6cfoSAY2kur9WNSPT7I5KzwWChBf0R+hnQw7kfyx+h0BnaT6v1Y1I9F6HCVmpvXTg+cIm2hh3IflidQY2kur9WNSPRHPQQ7kfyxMaGPcj+VHUDaT6v1Y1V0RrFJaklywNgGeT0D1WQcmaKOkmuvJau7HdzIeQckX3Vqiw9yL28WekLForAav71i38l+fgh8fitb9uHn8EOr2nzNTar2nzNSdIwAAAnXC4yACFJ4vmzGc9782J63zfxMAFflPI+ljpKeE9q2T/c83KLTaauawaeDTPfUOz5kHKmS4Vlf2Z7JL570Q2P0Wrc7Kt0ua5MkMLjXX9M+HsePB2tlinRlmzjdua7L5M4lalGUG4yWTJqMlJZrgADBgyZAAAQAAAAAAAAAAAABvQoSqSzYJyb3GUm3kg2ks2aF9kXIt91SsuMYvbxl9CZknIsaV06l0p7O7HlvfEuCw4DRWq1Zfx5L5+CHxWO1vor9fgh5z3vzMZz3vzZgE6RhMpLqrkbXGtLsrkbgGLgZABD00t/ohppb/RGgAJMaaava18WbaGO71ZtT1LkjYAjVJOLujgvM000t/ojNo7XkcwDo6aqpqolJbmU1v6PPtUX/TJ/B/UvLLt8CQc2IwlWIWU15815m6q+yp5xfwfPq1GUHmzi4virvI1PdWylGUbpRUsdqvKa0ZEg+w3D+5EFfoWyO+p59z3P4JOrSUH21l90eeBYVcjVV2Up/hePkyJVstSHapzjziyMsw1tfbi15HbC6ufZkn5nIAGk2gAxeAZBvTs85dmEpcotkunkes9cczm0vQ210W2diLfkzXO2EO00iCIQcndFNt6kk2/JF5QyFFYzm5cF1V5lxYLNCDuhFRw2LHzJKjQ1099j1V6v4OO3SNcews/siksPR6csarzFuWMn9C/oWOFKN1OObd4t895LNK3ZZO4bBU4fsLf1fH++BF3Yiy3tPy5EbTS3+iGmlv8ARGgOs0EvQx3erGhju9WdAARZVGncngtWo100t/ojFXtPmagG+mlv9EDQAAAAE2nqXJGwABEtHa8jmAAd7Lt8CQAAcrR2fFEZAAwbUta5kreAZXAPkedyxtKGWsAp+kf9hO4DsGpcZJ1oA14H/ajZjf8AUeqhqOFp1oyC5rslf5nE6WbX4AAwSjSt2WYAMkQAAE8AAEKr2nzNQAAAAD//2Q==" class="rounded-circle user_img_msg"/>
								</div>
								<div class="msg_cotainer">
                                <h6 >@{tweet.username}</h6>
                                <div>{tweet.tweet}							
                                    
								</div>
                                
                                <div class="msg_time">{tweet.timeAgo}</div>
							</div>
                            
                        </div>
                        
                       <button onClick={() => { this.likeTweet(tweets.id,tweets.username)
                     }}>
                         
                           <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAARMAAAC3CAMAAAAGjUrGAAAA9lBMVEX///9VrO7/Bwf/AABNqe1Epu1Pqu5Gp+33+/6dzPT/0QBXre6izvX/zwD/9/fp8/18vfHc7Pux1vbI4vlhse+p0vX/19f/jo7i8Py+3fiMxPPm8vy42ff/4OD/VFT/oaH/X1//xcX/Z2fW6fpxuPD/s7N4u/H/urr/LS3/ior/mpr/5+f/1NT/7u7/fHxEs/j/JCT//PD/++v/77z/883/PDz/RET/ZGT/wsL/GBj/bm7BYIXaQVr/goLYR2FtndqpdaFnoN31GCHjHzmefa22aZHvJTLNUnKvb5mIjcP/5Ir/3mf/1i//3FX/7Kz/99z/5pP/1z3RGxuKAAAIfElEQVR4nO2cCXObOhDHjdEBxgk+cAPUTZOaHD1SN22a17Sv7Tv6rjTp8f2/zAPj2NjGICR0QPjNJDPJYEb6W9pdrVZqtRoaGhoaGhoaGhoaRHP24PDk8JHsVqjD7sl7fc7bvQeyW6MCu3uRGO2YSJYT2S2SztFSkDtZTu/5WDlYUyRW5ansZklk9+2mIjNV9mW3TB6v0iUJRbmU3TRZ7G+TJBTlQHbj5PBsuyShKI9lN08Gz7MkCUV5LruBEsiYOffVzr7IliQU5YXsJgrnIFeTX2Q3UTQ51mQmyq7sRgpmj0CTI9mNFExKTL+hyRPZjRTLYb4kbb0dP7t7uPfk8vTq7cHeu1rPppcEmrT1s/DJk0s9wcGh7Jbz44pIkxdhrLs6yXT9tK6qEHidSICXV5tmR6+rmXlHpEk73RDr7VombjOXfwRS1THEJTKxWaLUcKTkBva5otTPK+esiQlEqZ+hZdakrdfOJbPOnVCTU9l9KBtGGzsTpW6+h80Xx5q8l92JkjkpQRNddidK5hG7Jm29Uluotmf2HIQxRk7P9B6mPUKQPsnVpDopp77pQACQFoMAgJY/2Xgq4Yxp5dGfSegdDeNQEG0dBK3B2nOPl9UVH36lE0X/KKWHRRlreEOQGABWVZkbFF3/9HlKO06qoInrbFMkAlsrM+hKjwpwQkWmv9FqssevK32jnPd0IcqQJASaiaej6qQPv081bfoHrSYcd5QDp4y3GEHWIJlPIGcp/6M/v2ihItr0C60H4rjimUDQY3+LbeUMkhkIzR2zO3Km8b+mW2tQcjU5Y2/2Fo6Rhs38x7KxEYkkIdgNoxffWjin6V/UkvBbBNowmukjtpcYpJKEQyXUI/HwZ+rYjWN4Mpp9Y3A9fiiGQyzJGtO/6TXhN3Xm3YFjhnf0NsM0Qkn+oZeE37LYgPPmMYyUMczseIYk/9KvejiWMQ0XHpTaptjUklC7Yb5BbHc57CGl9+lRGhMwol8cc83bJzuEqeKUCe0wMYNP9JrwzBNYK99cQBHmB5TDxEHoP+rYhGtJ8eqXjDS36Av6tMNEo1/q6Bz9cMLt3AG9gm/waUOTSBPKJTHfvZ0NTTToF3tB/sovA4tKE84l1puahIvXIvNnyKIJHtDs8/A+yZKiiYaKRCosU0dzKPL3Os9UUkyqhcROaq49DSvt84TASau15QBPhiT8s/XpfUKwS/Zx6hg2BESW66iYJvorAYUn24JQoA1JPj5hMCdo9oYisayAeRPR3bqkhQGBrR3TrojjmRPykVQTXdff8wxLlmT4DQR7dt7Ht0uaB5ivrgitbKjIUzGKpDuehCp+jrE1ad0OCu5ecUlQZK7r+yI3QrOXK+FY6Wd9mtoVo0VomGNl9ZkgooZIzCBn9CPoZIT79JosxkmGlY30uHopvsg+35siDMxt5rYMTdJj2bi6/kjOoUCSlBCAzijVspjUNna50fYgpXw80uOxvBpYwsV+KEt3s2Qib+aRaLJ28jrWQ3K9DXFSCGDQG6yaXPolYEKTRd1FbFCfKVC85xaIzxHAODC9xbY7dWyfsCetM/1Oj1d7qlS9FjQKCAAMUeB3B8NJn3buJDVp7c8MyJMTsR43G6pOhdKEg4ZSEg0l8+En+qly9+MUmT0lgVbSeSoew6feyaMGMJcycMdkSqvSaMJYycCRxcLXFywKKLo/II4hHszdqil2+mCilJUUJhhgMw7DxNoUWHhzTRiRx0EQ+Z5rtFxHpCYlFVtyYJ5SQgBiKwgEaoJk9zyDhGll2akpLMmx7I5nQFsVwIjS4Ql9AoRNE3VdMeN+Lz0Kux3WugBqgOx+Z0JbjcbESqZAPaRMHkC4HS0LGeMEb2Z2lYI+zcygibpRbIx4TRQ3JyFj4RYFsJ14EAH1qQpaIHEZlDQeis48WrJ7TIDgdKzqnjjGF2pnlQ7slwQiRSnlnKoABIpSAa8z51iYKDC3Sk4ZfEGGFpVwmlkYHhYSp6i+1lnFPhYxVKoQnCQZWtzHCmA5tCuHYZByp0upmqi+JE7DNa28SztYJKlEDJuCy3QqJxOF9/9ScPzuYOyNB2bP4WdUKjZMTAxieFpZ5RNsq7AcTyJF4UqcdATsaqi8c54Ky+lpMrDKO6Lp8PM2MagqSYIEvPdJK5JLWoVvBl/p+ort8DWzsntHh0F0yxodsFI5ggQ2twUgKHY3hEq4vExK1dImSVw+sX0lfc4Cw+EwfxjvxJNP+dnqMm7ZlMwQlDtUqhjAbmCYpabacHV2dLKwfViasa1sZLKBMQ4gJr8DNUMSdY+lUGB7ZgAgYyK/8i4nBcP2WAYL6S1E1cJjum6smovhbIweS7RCe9eo0gyZvE8dJ85Dtl111qu/FYQ1cit8n6byGCM2J4yqVWhCgG1itrAEWPUI6BdMeqwVF3T3OCuL29WYN9HrFLwaE9NiL8oBVqWzagnsYTfAjFYkHiSVTUcPR95k0nfd/mToDUzfwbCcMgtgVdjfDAHEGIY/uMSiE1T1aH5UxkxZVeS48h647ByjU4v0ke2XpgrWahPL234ZMwjhrOtDq4cxQoxBGoDHtZg1K7CUT0d3qap/6JEGe0QVwCKMe/UbIkvcrlNoUye6ELPnVavilQJ73ANEuoR6pF4oW1Pcse/A7YH+7FpQqzea1H6ArGH0vW60BApDf3AHnv3p9MzxvZMjiWG74QrR8wbjsTccTlz7/orxWnYD1OPiWnYLlOI8+tVpNElyfvP1zfXOV9nNUIvXO51O5+bNuex2KMVFqElnZ+e2sbNLvkWaXH+X3QyVON/ZuencyG6FWtz+eN362ZHdCgX4cdG6SNiP80aT0K7u3P5M/t1Yk9b3287OG9mNUIvzb9eh972Q3QzVuPnezJd1vsluQENDQ0NDQ0NDQ0NDw1b+ByPBmPrd5efFAAAAAElFTkSuQmCC" class="rounded-circle user_img_msg_like"/>
                        {tweets.like}
                       </button> 
                    
                        <button className="btn btn-primary btn">reply</button>
                        <button className="btn btn-primary btn" onClick={() => this.edittweet(tweet.id,tweet.username)} >update</button>
                        <button className="btn btn-primary btn" onClick={() => this.deletetweet(tweet.id,tweet.username)} >Delete</button>
                        </div>
       ): null                   
    }
                    
                 
            <Link to="/postTweet" className="btn btn-primary">Post</Link>
           <div align="right"><Link to="/alltweet" >Go- back</Link></div> 
           
            </div>
        )
        
    }

}

export default MyTweetComponent;
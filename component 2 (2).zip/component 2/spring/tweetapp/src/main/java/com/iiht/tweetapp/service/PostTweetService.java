package com.iiht.tweetapp.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

//import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.iiht.tweetapp.model.TweetUser;
import com.iiht.tweetapp.repository.ReplyRepository;
import com.iiht.tweetapp.repository.TweetRepository;
import com.iiht.tweetapp.repository.UserRepository;

@Service
public class PostTweetService {

	@Autowired
	TweetRepository tweetRepo;
	
	@Autowired
	ReplyRepository replyRepo;

	@Autowired
	UserRepository userRepo;

	public TweetUser postTweet(String username, TweetUser tweetuser) {

		/*
		 * TweetUser tweetuser = new TweetUser();
		 * 
		 * TweetUser register = tweetRepo.findByUsername(username); boolean exist =
		 * register==null?true:false;
		 * 
		 * if(!exist) {
		 */
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		System.out.println(dtf.format(now));
		String time = dtf.format(now);

		tweetuser.setUsername(username);
		tweetuser.setLike(0);
		tweetuser.setTime(time);
		/*
		 * ArrayList<String> arr = new ArrayList<String>(); arr.add(tweet);
		 * tweetuser.setTweet(arr);
		 */

		/*
		 * ReplyUser reply = new ReplyUser(); reply.setTweet(tweetuser.getTweet());
		 * replyRepo.save(reply);
		 */
		return tweetRepo.save(tweetuser);
		/*
		 * }else {
		 * 
		 * TweetUser user = new TweetUser(); Integer len = user.getTweet().size();
		 * 
		 * register.setTweet((tweetuser.getTweet())); return tweetRepo.save(register);
		 * 
		 * listdata.add(tweetuser.getTweet()); register.setTweet(listdata);
		 * 
		 * }
		 */

	}

}

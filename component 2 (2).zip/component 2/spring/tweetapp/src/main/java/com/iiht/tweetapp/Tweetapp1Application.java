package com.iiht.tweetapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tweetapp1Application {

	public static void main(String[] args) {
		SpringApplication.run(Tweetapp1Application.class, args);
	}

}

package com.iiht.tweetapp.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "ReplyTweet")
public class ReplyUser {
	
	@Id
	private String id;
	private String username;
	private String tweetId;
	private String replyTweet;
	private long like;
	private String time;
	private String timeAgo;
	
	
	public ReplyUser() {
		super();
		// TODO Auto-generated constructor stub
	}
	public long getLike() {
		return like;
	}
	public void setLike(long i) {
		this.like = i;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getTimeAgo() {
		return timeAgo;
	}
	public void setTimeAgo(String timeAgo) {
		this.timeAgo = timeAgo;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getTweetId() {
		return tweetId;
	}
	public void setTweetId(String tweet) {
		this.tweetId = tweet;
	}
	public String getReplyTweet() {
		return replyTweet;
	}
	public void setReplyTweet(String replyTweet) {
		this.replyTweet = replyTweet;
	}
	public ReplyUser(String id, String username, String tweetId, String replyTweet) {
		super();
		this.id = id;
		this.username = username;
		this.tweetId = tweetId;
		this.replyTweet = replyTweet;
	}
	

	
}
